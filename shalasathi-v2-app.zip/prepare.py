# Best effort: ऑफलाईन वापरासाठी लायब्ररी व फॉन्ट अँपमध्येच घेतो. काही चुकले तर जुनेच इंटरनेट लिंक राहतात.
import re, os, urllib.request
W = 'www'
V = os.path.join(W, 'vendor')
os.makedirs(os.path.join(V, 'fonts'), exist_ok=True)
P = os.path.join(W, 'index.html')
t = open(P, encoding='utf-8').read()
UA = {'User-Agent': 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36'}

def get(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=40) as r:
        return r.read()

def safe(url):
    return re.sub(r'[^A-Za-z0-9._-]', '_', url.split('//', 1)[1])

for u in sorted(set(re.findall(r'<script[^>]*src="(https://[^"]+)"', t))):
    try:
        d = get(u)
        if len(d) < 2000:
            raise Exception('file too small')
        n = safe(u)
        open(os.path.join(V, n), 'wb').write(d)
        t = t.replace(u, 'vendor/' + n)
        print('OK   ', u)
    except Exception as e:
        print('SKIP ', u, e)

m = re.search(r'<link href="(https://fonts\.googleapis\.com/css2[^"]+)"', t)
if m:
    try:
        css = get(m.group(1).replace('&amp;', '&')).decode('utf-8')
        def rep(x):
            u = x.group(1)
            n = safe(u)
            open(os.path.join(V, 'fonts', n), 'wb').write(get(u))
            return 'url(fonts/' + n + ')'
        css2 = re.sub(r'url\((https://[^)]+)\)', rep, css)
        open(os.path.join(V, 'fonts.css'), 'w', encoding='utf-8').write(css2)
        t = t.replace(m.group(1), 'vendor/fonts.css')
        print('OK    fonts')
    except Exception as e:
        print('SKIP  fonts', e)

open(P, 'w', encoding='utf-8', newline='').write(t)
print('prepare done')
